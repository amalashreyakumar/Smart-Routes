
/*
  script.js
  - Animates the SVG route by reducing strokeDashoffset and moves a dot along the path
  - No external APIs required. Works offline after download.
*/

document.addEventListener('DOMContentLoaded', function(){
  const runBtn = document.getElementById('runBtn');
  const route = document.getElementById('route');
  const traveler = document.getElementById('traveler');
  const resultInfo = document.getElementById('resultInfo');

  // total length for the stroke-dash trick
  const totalLen = route.getTotalLength();
  route.style.strokeDasharray = totalLen;
  route.style.strokeDashoffset = totalLen;

  let animId = null;

  function animateRoute(duration = 2200){
    traveler.setAttribute('visibility', 'visible');
    const start = performance.now();
    function frame(now){
      const elapsed = now - start;
      const t = Math.min(1, elapsed / duration);
      // ease function (easeInOutQuad)
      const ease = t<0.5 ? 2*t*t : -1 + (4-2*t)*t;
      // draw path
      route.style.strokeDashoffset = Math.round(totalLen * (1 - ease));
      // position traveler along path
      const point = route.getPointAtLength(totalLen * ease);
      traveler.setAttribute('cx', point.x);
      traveler.setAttribute('cy', point.y);

      if(t < 1){
        animId = requestAnimationFrame(frame);
      } else {
        // finished
        resultInfo.textContent = 'Shortest Path Found! Distance: 347 km | Estimated Time: 6 hours';
      }
    }
    animId = requestAnimationFrame(frame);
  }

  runBtn.addEventListener('click', function(){
    // reset if needed
    cancelAnimationFrame(animId);
    route.style.strokeDashoffset = totalLen;
    traveler.setAttribute('visibility', 'hidden');
    resultInfo.textContent = 'Running A*...';
    // small simulated delay, then animate
    setTimeout(()=> animateRoute(2500), 400);
  });
});

// ---------- A* calculation UI and algorithm (uses same waypoint coords) ----------
(function(){
  // same coordinates used for route animation (index matches HTML select)
  const nodes = [
    {id:0, name:'Bengaluru',  x:188, y:260},
    {id:1, name:'Waypoint 1', x:300, y:240},
    {id:2, name:'Waypoint 2', x:450, y:220},
    {id:3, name:'Waypoint 3', x:612, y:202},
    {id:4, name:'Chennai',    x:612, y:202} // same as waypoint 3 visually, but index kept for demo
  ];

  // Define neighbors for a simple linear graph (each node neighbors with previous and next)
  const neighbors = {
    0: [1],
    1: [0,2],
    2: [1,3],
    3: [2,4],
    4: [3]
  };

  function heuristic(aIdx, bIdx){
    const a = nodes[aIdx], b = nodes[bIdx];
    const dx = a.x - b.x, dy = a.y - b.y;
    return Math.hypot(dx, dy); // euclidean
  }

  function aStar(startIdx, goalIdx){
    // A* over small graph
    const openSet = new Set([startIdx]);
    const cameFrom = {}; // map node->parent
    const gScore = Array(nodes.length).fill(Infinity);
    const fScore = Array(nodes.length).fill(Infinity);
    gScore[startIdx] = 0;
    fScore[startIdx] = heuristic(startIdx, goalIdx);

    const history = []; // record steps for UI

    while(openSet.size){
      // get node in open with lowest fScore
      let current = null;
      let best = Infinity;
      openSet.forEach(n => {
        if(fScore[n] < best){ best = fScore[n]; current = n; }
      });

      history.push({
        action: 'select',
        current,
        open: Array.from(openSet),
        closed: Object.keys(cameFrom).map(x=>+x)
      });

      if(current === goalIdx){
        // reconstruct path
        const path = [];
        let temp = current;
        while(temp !== undefined){
          path.push(temp);
          temp = cameFrom[temp];
        }
        path.reverse();
        return {status:'success', path, gScore: gScore[goalIdx], history};
      }

      openSet.delete(current);

      // for each neighbor
      for(const nb of neighbors[current] || []){
        const tentativeG = gScore[current] + heuristic(current, nb);
        if(tentativeG < gScore[nb]){
          cameFrom[nb] = current;
          gScore[nb] = tentativeG;
          fScore[nb] = tentativeG + heuristic(nb, goalIdx);
          if(!openSet.has(nb)){
            openSet.add(nb);
            history.push({action:'add', node:nb, from:current, g:gScore[nb], h:heuristic(nb,goalIdx), f:fScore[nb]});
          } else {
            history.push({action:'update', node:nb, from:current, g:gScore[nb], h:heuristic(nb,goalIdx), f:fScore[nb]});
          }
        }
      }
      // push closed state snapshot
      history.push({action:'close', node:current, open:Array.from(openSet), closed:Object.keys(cameFrom).map(x=>+x)});
    }

    return {status:'fail', history};
  }

  // UI hooks
  const runBtn = document.getElementById('runAstarBtn');
  const startSelect = document.getElementById('startSelect');
  const goalSelect = document.getElementById('goalSelect');
  const calcResult = document.getElementById('calcResult');
  const calcTables = document.getElementById('calcTables');

  function renderHistoryTables(result){
    calcTables.innerHTML = '';
    if(result.status === 'fail'){
      calcResult.textContent = 'A* failed to find a path.';
      return;
    }
    const {path, gScore, history} = result;
    // Summary
    const sum = document.createElement('div');
    sum.innerHTML = `<p><strong>Path:</strong> ${path.map(i => `<span class="path-node">${nodes[i].name}</span>`).join(' → ')} &nbsp; | &nbsp; <strong>Cost (g):</strong> ${gScore.toFixed(2)}</p>`;
    calcTables.appendChild(sum);

    // Table for node values (g,h,f) at the end
    const finalTable = document.createElement('table');
    finalTable.innerHTML = `<thead><tr><th>Node</th><th>g (cost)</th><th>h (heuristic)</th><th>f = g+h</th></tr></thead>`;
    const tbody = document.createElement('tbody');
    nodes.forEach((n,i) => {
      // compute final values
      const g = (i === path[0]) ? 0 : (path.includes(i) ? 'on path' : '-');
      const h = heuristic(i, path[path.length-1]).toFixed(2);
      let gval = '-';
      // best-effort compute g by summing along path if node on path
      if(path.includes(i)){
        const idx = path.indexOf(i);
        let sumg = 0;
        for(let k=0;k<idx;k++){
          sumg += heuristic(path[k], path[k+1]);
        }
        gval = sumg.toFixed(2);
      }
      const f = (gval === '-') ? '-' : ( (parseFloat(gval) + parseFloat(h)).toFixed(2) );
      const row = `<tr><td>${n.name}</td><td>${gval}</td><td>${h}</td><td>${f}</td></tr>`;
      tbody.insertAdjacentHTML('beforeend', row);
    });
    finalTable.appendChild(tbody);
    calcTables.appendChild(finalTable);

    // Steps log (compact)
    const stepsHeader = document.createElement('h4');
    stepsHeader.textContent = 'Computation Steps (summary)';
    calcTables.appendChild(stepsHeader);
    const stepsList = document.createElement('ol');
    history.forEach(step=>{
      let text = '';
      if(step.action === 'select'){
        text = `Selected node: ${nodes[step.current].name} — Open: [${step.open.map(i=>nodes[i].name).join(', ')}]`;
      } else if(step.action === 'add'){
        text = `Added ${nodes[step.node].name} from ${nodes[step.from].name} (g=${step.g.toFixed(2)}, h=${step.h.toFixed(2)}, f=${step.f.toFixed(2)})`;
      } else if(step.action === 'update'){
        text = `Updated ${nodes[step.node].name} via ${nodes[step.from].name} (g=${step.g.toFixed(2)}, f=${step.f.toFixed(2)})`;
      } else if(step.action === 'close'){
        text = `Closed ${nodes[step.node].name}`;
      } else {
        text = JSON.stringify(step);
      }
      const li = document.createElement('li');
      li.textContent = text;
      stepsList.appendChild(li);
    });
    calcTables.appendChild(stepsList);
    calcResult.textContent = 'A* computation finished.';
  }

  runBtn.addEventListener('click', function(){
    const start = parseInt(startSelect.value,10);
    const goal = parseInt(goalSelect.value,10);
    if(start === goal){
      calcResult.textContent = 'Start and goal are the same.';
      calcTables.innerHTML = '';
      return;
    }
    calcResult.textContent = 'Running A*...';
    setTimeout(()=>{
      const res = aStar(start,goal);
      renderHistoryTables(res);
      // Optionally: trigger the SVG animation and highlight path visually
      // If you want to also animate the SVG route for the computed path, we can do that.
    }, 150);
  });

})();



