
let map = L.map('map').setView([12.9716, 77.5946], 7);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

let routeLine = null;

document.getElementById('findBtn').addEventListener('click', () => {
  const startVal = document.getElementById('start').value.split(',').map(Number);
  const endVal = document.getElementById('end').value.split(',').map(Number);
  const start = L.latLng(startVal[0], startVal[1]);
  const end = L.latLng(endVal[0], endVal[1]);

  if (routeLine) {
    map.removeLayer(routeLine);
  }

  const points = [start, end];
  routeLine = L.polyline(points, { color: '#b594e8', weight: 5 }).addTo(map);
  map.fitBounds(routeLine.getBounds());

  const distance = start.distanceTo(end) / 1000; // in km
  const time = (distance / 60).toFixed(2); // assuming 60 km/h

  document.getElementById('buddyOutput').innerHTML = `
    <p><strong>Total Distance:</strong> ${distance.toFixed(1)} km</p>
    <p><strong>Estimated Time:</strong> ${time} hours</p>
  `;
});

document.getElementById('resetBtn').addEventListener('click', () => {
  if (routeLine) map.removeLayer(routeLine);
  document.getElementById('buddyOutput').innerHTML = 'Distance and time will appear here.';
});
